// CANVAS

window.onload = zeichnen;

function zeichnen() {
    var canvas = document.getElementById("mein_canvas");
    var context = canvas.getContext("2d");

    context.font = "60px Verdana";
    // gradient
    var gradient = context.createLinearGradient(0, 0, canvas.width, 0);
    gradient.addColorStop("0", "magenta");
    gradient.addColorStop("0.5", "blue");
    gradient.addColorStop("1.0", "red");
    // canvas text
    context.strokeStyle = gradient;
    context.strokeText("HTML5!", 10, 50);
}